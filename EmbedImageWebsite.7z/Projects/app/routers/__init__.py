"""
Router package for EmPy
""" 